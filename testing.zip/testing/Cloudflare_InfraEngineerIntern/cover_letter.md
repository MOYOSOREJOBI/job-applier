Cloudflare stands out to me because infrastructure Engineer Intern — Cloudflare Cloudflare is hiring an Infrastructure Engineer Intern to work on our global edge network. I am excited by teams that care about useful systems, strong execution, and learning fast from real problems.

Infrastructure Engineer Intern lines up with the kind of work I want to keep doing: infrastructure and reliability engineering. My background is strongest where software, data, and reliable delivery overlap, so this role feels like a strong match for how I already work and where I want to keep growing. I am authorized to work in Canada.

One project that maps closely is my distributed payment gateway work, where I designed a containerized backend, added failure containment patterns including circuit breakers and idempotency, and provisioned the full infrastructure with Terraform. That project pushed me to think carefully about tradeoffs, reliability, and the shape of a system after other people start relying on it. I bring the same mindset to professional work, clear thinking, quick iteration, and a habit of making the next step easier for the team.

I like work that starts with a messy system, gets narrowed into a clear plan, and ends with something more reliable and observable than it was before. I care about clean communication, useful feedback, and writing work that another engineer can pick up without guessing what I meant.

My coursework in Data Structures and Algorithms, Software Architecture, and Software Testing has given me a strong base for this kind of work.

Thank you for considering my application. I would be glad to speak more about how I could contribute at Cloudflare, and I would love to hear from you soon.

Best regards,
Moyosore Ogunjobi
Software Engineering, University of Calgary '27
AWS Certified (4x) | github.com/MOYOSOREJOBI | moyosore.dev